require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

// Inline models to keep seed self-contained
const User = require('./models/User');
const Table = require('./models/Table');
const Settings = require('./models/Settings');

async function seed() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('Connected to MongoDB');

    // Create admin user if none exists
    const existing = await User.findOne({ role: 'Admin' });
    if (!existing) {
      await User.create({
        name: 'Admin',
        email: 'admin@restaurant.com',
        password: 'admin123',
        role: 'Admin',
      });
      console.log('✅ Admin created: admin@restaurant.com / admin123');
    } else {
      console.log('ℹ️  Admin already exists, skipping');
    }

    // Create sample tables if none exist
    const tableCount = await Table.countDocuments();
    if (tableCount === 0) {
      const tables = [
        { number: 1, capacity: 2, location: 'Window' },
        { number: 2, capacity: 2, location: 'Window' },
        { number: 3, capacity: 4, location: 'Main Hall' },
        { number: 4, capacity: 4, location: 'Main Hall' },
        { number: 5, capacity: 4, location: 'Main Hall' },
        { number: 6, capacity: 6, location: 'Main Hall' },
        { number: 7, capacity: 6, location: 'Terrace' },
        { number: 8, capacity: 8, location: 'Terrace' },
        { number: 9, capacity: 10, location: 'Private Room' },
        { number: 10, capacity: 12, location: 'Private Room' },
      ];
      await Table.insertMany(tables);
      console.log('✅ 10 tables created');
    } else {
      console.log(`ℹ️  ${tableCount} tables already exist, skipping`);
    }

    // Create default settings if none exist
    const settingsExist = await Settings.findOne();
    if (!settingsExist) {
      await Settings.create({
        restaurantName: 'The Grand Table',
        openingTime: '12:00',
        closingTime: '22:00',
        maxPartySize: 12,
        reservationDuration: 90,
      });
      console.log('✅ Default settings created');
    }

    console.log('\n🚀 Seed complete. You can log in as:');
    console.log('   Email:    admin@restaurant.com');
    console.log('   Password: admin123\n');

    process.exit(0);
  } catch (err) {
    console.error('Seed failed:', err.message);
    process.exit(1);
  }
}

seed();
