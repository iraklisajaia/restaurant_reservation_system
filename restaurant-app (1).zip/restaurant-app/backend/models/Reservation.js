const mongoose = require('mongoose');

const historySchema = new mongoose.Schema({
  status: String,
  changedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  changedByName: String,
  note: String,
  timestamp: { type: Date, default: Date.now }
});

const reservationSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  customerName: { type: String, required: true },
  customerEmail: { type: String, required: true },
  customerPhone: { type: String, default: '' },
  tableNumber: { type: Number, required: true },
  date: { type: String, required: true },   // "YYYY-MM-DD"
  time: { type: String, required: true },   // "HH:MM"
  partySize: { type: Number, required: true, min: 1 },
  occasion: { type: String, default: '' },
  notes: { type: String, default: '' },
  status: {
    type: String,
    enum: ['Pending', 'Confirmed', 'Seated', 'Completed', 'Cancelled'],
    default: 'Pending'
  },
  history: [historySchema],
  createdAt: { type: Date, default: Date.now }
});

// Prevent double-booking: same table, same date, same time
reservationSchema.index(
  { tableNumber: 1, date: 1, time: 1 },
  { unique: true, partialFilterExpression: { status: { $nin: ['Cancelled'] } } }
);

module.exports = mongoose.model('Reservation', reservationSchema);
