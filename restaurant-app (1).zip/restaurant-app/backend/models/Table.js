const mongoose = require('mongoose');

const tableSchema = new mongoose.Schema({
  number: { type: Number, required: true, unique: true },
  capacity: { type: Number, required: true },
  location: { type: String, default: 'Main Hall' },
  isActive: { type: Boolean, default: true }
});

module.exports = mongoose.model('Table', tableSchema);
