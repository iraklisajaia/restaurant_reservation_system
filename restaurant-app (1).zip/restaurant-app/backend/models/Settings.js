const mongoose = require('mongoose');

const settingsSchema = new mongoose.Schema({
  restaurantName: { type: String, default: 'The Grand Table' },
  openingTime: { type: String, default: '12:00' },
  closingTime: { type: String, default: '22:00' },
  maxPartySize: { type: Number, default: 12 },
  reservationDuration: { type: Number, default: 90 }, // minutes
  updatedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Settings', settingsSchema);
