const request = require('supertest');
const app = require('../server');

// Mock mongoose so tests run without a real DB
jest.mock('mongoose', () => {
  const actual = jest.requireActual('mongoose');
  return {
    ...actual,
    connect: jest.fn().mockResolvedValue({ connection: { host: 'mock' } }),
  };
});

// Mock models
jest.mock('../models/User', () => {
  const mockUser = {
    _id: 'user123',
    name: 'Test User',
    email: 'test@example.com',
    role: 'Customer',
    isActive: true,
    matchPassword: jest.fn().mockResolvedValue(true),
  };
  const MockUser = jest.fn().mockImplementation(() => mockUser);
  MockUser.findOne = jest.fn();
  MockUser.findById = jest.fn();
  MockUser.create = jest.fn().mockResolvedValue(mockUser);
  return MockUser;
});

jest.mock('../models/Reservation', () => {
  const MockReservation = jest.fn().mockImplementation(() => ({
    save: jest.fn().mockResolvedValue(true),
  }));
  MockReservation.find = jest.fn().mockResolvedValue([]);
  MockReservation.findOne = jest.fn().mockResolvedValue(null);
  MockReservation.findById = jest.fn();
  MockReservation.create = jest.fn();
  return MockReservation;
});

jest.mock('../models/Notification', () => ({
  create: jest.fn().mockResolvedValue(true),
  find: jest.fn().mockReturnValue({ sort: jest.fn().mockReturnValue({ limit: jest.fn().mockResolvedValue([]) }) }),
  updateMany: jest.fn().mockResolvedValue(true),
}));

jest.mock('../models/Settings', () => {
  const MockSettings = jest.fn().mockImplementation(() => ({ save: jest.fn().mockResolvedValue(true) }));
  MockSettings.findOne = jest.fn().mockResolvedValue({
    restaurantName: 'The Grand Table',
    openingTime: '12:00',
    closingTime: '22:00',
  });
  return MockSettings;
});

jest.mock('../models/Table', () => {
  const MockTable = jest.fn();
  MockTable.find = jest.fn().mockReturnValue({ sort: jest.fn().mockResolvedValue([]) });
  return MockTable;
});

jest.mock('../models/Waitlist', () => {
  const MockWaitlist = jest.fn();
  MockWaitlist.find = jest.fn().mockReturnValue({ sort: jest.fn().mockReturnValue({ limit: jest.fn().mockResolvedValue([]) }) });
  MockWaitlist.create = jest.fn();
  return MockWaitlist;
});

const User = require('../models/User');

// ─── TEST 1: Register returns 400 if fields missing ─────────────────────────
test('POST /api/auth/register - missing fields returns 400', async () => {
  const res = await request(app)
    .post('/api/auth/register')
    .send({ email: 'no-name@test.com' });
  expect(res.statusCode).toBe(400);
  expect(res.body.message).toMatch(/required/i);
});

// ─── TEST 2: Register fails if email already exists ──────────────────────────
test('POST /api/auth/register - duplicate email returns 409', async () => {
  User.findOne.mockResolvedValueOnce({ email: 'exists@test.com' });
  const res = await request(app)
    .post('/api/auth/register')
    .send({ name: 'Test', email: 'exists@test.com', password: 'pass123' });
  expect(res.statusCode).toBe(409);
});

// ─── TEST 3: Login fails with wrong credentials ───────────────────────────────
test('POST /api/auth/login - wrong password returns 401', async () => {
  User.findOne.mockResolvedValueOnce({
    matchPassword: jest.fn().mockResolvedValue(false),
    isActive: true,
  });
  const res = await request(app)
    .post('/api/auth/login')
    .send({ email: 'user@test.com', password: 'wrongpass' });
  expect(res.statusCode).toBe(401);
});

// ─── TEST 4: Login fails with missing fields ──────────────────────────────────
test('POST /api/auth/login - missing fields returns 400', async () => {
  const res = await request(app)
    .post('/api/auth/login')
    .send({ email: 'user@test.com' });
  expect(res.statusCode).toBe(400);
});

// ─── TEST 5: Protected route rejects unauthenticated request ─────────────────
test('GET /api/reservations - no token returns 401', async () => {
  const res = await request(app).get('/api/reservations');
  expect(res.statusCode).toBe(401);
});

// ─── TEST 6: Settings endpoint returns data ───────────────────────────────────
test('GET /api/settings - requires auth', async () => {
  const res = await request(app).get('/api/settings');
  expect(res.statusCode).toBe(401);
});
