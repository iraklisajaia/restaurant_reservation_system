const express = require('express');
const router = express.Router();
const Reservation = require('../models/Reservation');
const Waitlist = require('../models/Waitlist');
const Notification = require('../models/Notification');
const { protect, authorize } = require('../middleware/auth');

// Helper: create notification
const notify = async (userId, message, type = 'info') => {
  try { await Notification.create({ user: userId, message, type }); } catch (_) {}
};

// GET /api/reservations - Customers see their own; Staff/Admin see all
router.get('/', protect, async (req, res) => {
  try {
    const filter = req.user.role === 'Customer' ? { user: req.user._id } : {};
    const reservations = await Reservation.find(filter).sort({ date: -1, time: -1 });
    res.json(reservations);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/reservations/check-availability
router.get('/check-availability', protect, async (req, res) => {
  try {
    const { date, time } = req.query;
    const bookedTables = await Reservation.find({
      date, time, status: { $nin: ['Cancelled'] }
    }).select('tableNumber');
    res.json({ bookedTables: bookedTables.map(r => r.tableNumber) });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST /api/reservations
router.post('/', protect, async (req, res) => {
  try {
    const { tableNumber, date, time, partySize, occasion, notes, customerPhone } = req.body;

    // Check double-booking
    const conflict = await Reservation.findOne({
      tableNumber, date, time, status: { $nin: ['Cancelled'] }
    });
    if (conflict) {
      return res.status(409).json({ message: 'This table is already booked for that date and time. Please choose another slot.' });
    }

    const reservation = await Reservation.create({
      user: req.user._id,
      customerName: req.user.name,
      customerEmail: req.user.email,
      customerPhone: customerPhone || req.user.phone,
      tableNumber, date, time, partySize, occasion, notes,
      history: [{ status: 'Pending', changedByName: req.user.name, note: 'Reservation created' }]
    });

    await notify(req.user._id, `Your reservation for ${date} at ${time} (Table ${tableNumber}) has been received and is Pending.`, 'info');
    res.status(201).json(reservation);
  } catch (err) {
    if (err.code === 11000) {
      return res.status(409).json({ message: 'This table is already booked for that date and time.' });
    }
    res.status(500).json({ message: err.message });
  }
});

// PUT /api/reservations/:id/status - Staff/Admin advance workflow
router.put('/:id/status', protect, authorize('Staff', 'Admin'), async (req, res) => {
  try {
    const { status, note } = req.body;
    const validStatuses = ['Pending', 'Confirmed', 'Seated', 'Completed', 'Cancelled'];
    if (!validStatuses.includes(status))
      return res.status(400).json({ message: 'Invalid status' });

    const reservation = await Reservation.findById(req.params.id);
    if (!reservation) return res.status(404).json({ message: 'Reservation not found' });

    reservation.status = status;
    reservation.history.push({
      status, changedBy: req.user._id, changedByName: req.user.name,
      note: note || `Status changed to ${status}`
    });
    await reservation.save();

    await notify(reservation.user, `Your reservation on ${reservation.date} at ${reservation.time} is now ${status}.`,
      status === 'Cancelled' ? 'warning' : 'success');

    res.json(reservation);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT /api/reservations/:id - Customer edits their own pending reservation
router.put('/:id', protect, async (req, res) => {
  try {
    const reservation = await Reservation.findById(req.params.id);
    if (!reservation) return res.status(404).json({ message: 'Reservation not found' });

    if (req.user.role === 'Customer' && reservation.user.toString() !== req.user._id.toString())
      return res.status(403).json({ message: 'Not authorized' });

    if (reservation.status !== 'Pending' && req.user.role === 'Customer')
      return res.status(400).json({ message: 'Only pending reservations can be edited' });

    const { tableNumber, date, time, partySize, occasion, notes } = req.body;

    // Check double-booking if changing table/date/time
    if (tableNumber || date || time) {
      const conflict = await Reservation.findOne({
        tableNumber: tableNumber || reservation.tableNumber,
        date: date || reservation.date,
        time: time || reservation.time,
        status: { $nin: ['Cancelled'] },
        _id: { $ne: reservation._id }
      });
      if (conflict) return res.status(409).json({ message: 'That slot is already booked.' });
    }

    Object.assign(reservation, { tableNumber, date, time, partySize, occasion, notes });
    reservation.history.push({ status: reservation.status, changedByName: req.user.name, note: 'Reservation updated' });
    await reservation.save();
    res.json(reservation);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// DELETE /api/reservations/:id - Cancel (customers own, staff/admin any)
router.delete('/:id', protect, async (req, res) => {
  try {
    const reservation = await Reservation.findById(req.params.id);
    if (!reservation) return res.status(404).json({ message: 'Reservation not found' });

    if (req.user.role === 'Customer' && reservation.user.toString() !== req.user._id.toString())
      return res.status(403).json({ message: 'Not authorized' });

    reservation.status = 'Cancelled';
    reservation.history.push({ status: 'Cancelled', changedByName: req.user.name, note: 'Reservation cancelled' });
    await reservation.save();

    // Notify waitlist
    const waiting = await Waitlist.find({ date: reservation.date, time: reservation.time, status: 'Waiting' })
      .sort({ createdAt: 1 }).limit(1);
    if (waiting.length > 0) {
      waiting[0].status = 'Notified';
      await waiting[0].save();
      await notify(waiting[0].user, `Great news! A slot opened up on ${reservation.date} at ${reservation.time}. Book now!`, 'success');
    }

    res.json({ message: 'Reservation cancelled' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// --- WAITLIST ---

// GET /api/reservations/waitlist
router.get('/waitlist', protect, async (req, res) => {
  try {
    const filter = req.user.role === 'Customer' ? { user: req.user._id } : {};
    const list = await Waitlist.find(filter).sort({ createdAt: 1 });
    res.json(list);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST /api/reservations/waitlist
router.post('/waitlist', protect, async (req, res) => {
  try {
    const { date, time, partySize } = req.body;
    const entry = await Waitlist.create({
      user: req.user._id,
      customerName: req.user.name,
      customerEmail: req.user.email,
      customerPhone: req.user.phone,
      date, time, partySize
    });
    await notify(req.user._id, `You've been added to the waitlist for ${date} at ${time}.`, 'info');
    res.status(201).json(entry);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
