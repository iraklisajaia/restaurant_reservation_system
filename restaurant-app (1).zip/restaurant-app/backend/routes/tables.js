const express = require('express');
const router = express.Router();
const Table = require('../models/Table');
const Reservation = require('../models/Reservation');
const { protect, authorize } = require('../middleware/auth');

// GET /api/tables
router.get('/', protect, async (req, res) => {
  try {
    const tables = await Table.find({ isActive: true }).sort({ number: 1 });
    res.json(tables);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/tables/availability?date=&time=
router.get('/availability', protect, async (req, res) => {
  try {
    const { date, time } = req.query;
    const bookedTables = await Reservation.find({
      date, time, status: { $nin: ['Cancelled'] }
    }).select('tableNumber');
    const booked = bookedTables.map(r => r.tableNumber);
    const allTables = await Table.find({ isActive: true }).sort({ number: 1 });
    const result = allTables.map(t => ({ ...t.toObject(), available: !booked.includes(t.number) }));
    res.json(result);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST /api/tables - Admin only
router.post('/', protect, authorize('Admin'), async (req, res) => {
  try {
    const table = await Table.create(req.body);
    res.status(201).json(table);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT /api/tables/:id - Admin only
router.put('/:id', protect, authorize('Admin'), async (req, res) => {
  try {
    const table = await Table.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!table) return res.status(404).json({ message: 'Table not found' });
    res.json(table);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// DELETE /api/tables/:id - Admin only
router.delete('/:id', protect, authorize('Admin'), async (req, res) => {
  try {
    await Table.findByIdAndDelete(req.params.id);
    res.json({ message: 'Table deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
