# 🍽️ Restaurant Reservation System

A full-stack web application for managing restaurant reservations, built with React, Express.js, and MongoDB.

## Team
- Giorgi Khutsishvili
- Irakli Sajaia
- Abdel Latif Ghassan Abdel Qadir
- [Your Name]

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, React Router v6, Axios |
| Backend | Express.js 4, Node.js |
| Database | MongoDB Atlas + Mongoose |
| Auth | JWT (JSON Web Tokens) + bcryptjs |
| Testing | Jest + Supertest |

## Features

- **User Authentication** — Register, login, logout with JWT tokens and hashed passwords
- **Role-Based Access Control** — Customer, Staff, and Admin roles with server-enforced permissions
- **CRUD Operations** — Full create/read/update/delete for reservations, tables, and users
- **Workflow Stages** — Reservations move through: Pending → Confirmed → Seated → Completed (or Cancelled)
- **Double-Booking Prevention** — MongoDB compound index prevents two bookings for same table/date/time
- **Waitlist System** — Users can join a waitlist when all tables are booked; notified when a slot opens
- **In-App Notifications** — Users receive notifications on reservation status changes
- **Data History** — Every reservation status change is logged with timestamp and actor
- **Admin Management** — Admins can manage users (roles, activation), tables, and restaurant settings
- **Table Availability Check** — Real-time availability shown when selecting a booking slot

## Getting Started

### Prerequisites
- Node.js 18+
- MongoDB Atlas account (free tier works)

### Backend Setup

```bash
cd backend
npm install
```

Create a `.env` file:
```
PORT=5000
MONGO_URI=mongodb+srv://username:password@cluster.mongodb.net/restaurant_db
JWT_SECRET=your_secret_key_here
JWT_EXPIRE=7d
NODE_ENV=development
```

```bash
npm start       # production
npm run dev     # development with nodemon
npm test        # run tests
```

### Frontend Setup

```bash
cd frontend
npm install
npm start
```

The app runs on `http://localhost:3000` and expects the backend on `http://localhost:5000`.

To point to a deployed backend, create `frontend/.env`:
```
REACT_APP_API_URL=https://your-backend-url.com/api
```

## API Endpoints

### Auth
| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| POST | `/api/auth/register` | Register new user | Public |
| POST | `/api/auth/login` | Login | Public |
| GET | `/api/auth/me` | Get current user | Protected |

### Reservations
| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| GET | `/api/reservations` | List reservations | Customers: own only; Staff/Admin: all |
| POST | `/api/reservations` | Create reservation | Customer |
| PUT | `/api/reservations/:id` | Edit reservation | Customer (pending only) |
| DELETE | `/api/reservations/:id` | Cancel reservation | Customer (own) / Staff / Admin |
| PUT | `/api/reservations/:id/status` | Advance workflow status | Staff / Admin |
| GET | `/api/reservations/check-availability` | Check available tables | Protected |
| GET | `/api/reservations/waitlist` | View waitlist | Protected |
| POST | `/api/reservations/waitlist` | Join waitlist | Customer |

### Tables
| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| GET | `/api/tables` | List all tables | Protected |
| GET | `/api/tables/availability` | Tables with availability for date/time | Protected |
| POST | `/api/tables` | Add table | Admin |
| PUT | `/api/tables/:id` | Update table | Admin |
| DELETE | `/api/tables/:id` | Delete table | Admin |

### Users (Admin)
| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| GET | `/api/users` | List all users | Admin |
| PUT | `/api/users/:id/role` | Change user role | Admin |
| PUT | `/api/users/:id/status` | Activate/deactivate user | Admin |
| DELETE | `/api/users/:id` | Delete user | Admin |

### Notifications
| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| GET | `/api/notifications` | Get user's notifications | Protected |
| PUT | `/api/notifications/:id/read` | Mark one as read | Protected |
| PUT | `/api/notifications/read-all` | Mark all as read | Protected |

### Settings
| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| GET | `/api/settings` | Get restaurant settings | Protected |
| PUT | `/api/settings` | Update settings | Admin |

## Running Tests

```bash
cd backend
npm test
```

Tests cover: registration validation, duplicate email detection, wrong-password login, missing fields, protected route enforcement, and settings access control.

## Deployment

See the project guide for deployment instructions (Render for backend, Vercel/Netlify for frontend).
