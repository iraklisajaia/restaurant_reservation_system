import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import Navbar from './components/Navbar';
import Login from './pages/Login';
import Register from './pages/Register';
import Home from './pages/Home';
import BookTable from './pages/BookTable';
import ManageReservations from './pages/ManageReservations';
import Notifications from './pages/Notifications';
import AdminUsers from './pages/AdminUsers';
import AdminTables from './pages/AdminTables';
import AdminSettings from './pages/AdminSettings';
import './App.css';

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Navbar />
        <div className="main-content">
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/" element={<ProtectedRoute><Home /></ProtectedRoute>} />
            <Route path="/book" element={<ProtectedRoute><BookTable /></ProtectedRoute>} />
            <Route path="/notifications" element={<ProtectedRoute><Notifications /></ProtectedRoute>} />
            <Route path="/manage" element={<ProtectedRoute roles={['Staff', 'Admin']}><ManageReservations /></ProtectedRoute>} />
            <Route path="/admin/users" element={<ProtectedRoute roles={['Admin']}><AdminUsers /></ProtectedRoute>} />
            <Route path="/admin/tables" element={<ProtectedRoute roles={['Admin']}><AdminTables /></ProtectedRoute>} />
            <Route path="/admin/settings" element={<ProtectedRoute roles={['Admin']}><AdminSettings /></ProtectedRoute>} />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </div>
      </BrowserRouter>
    </AuthProvider>
  );
}
