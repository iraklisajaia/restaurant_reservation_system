import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="navbar">
      <div className="navbar-brand">
        <Link to="/">🍽️ The Grand Table</Link>
      </div>
      <div className="navbar-links">
        {user ? (
          <>
            <Link to="/">My Reservations</Link>
            <Link to="/book">Book a Table</Link>
            <Link to="/notifications">Notifications</Link>
            {(user.role === 'Staff' || user.role === 'Admin') && (
              <Link to="/manage">Manage</Link>
            )}
            {user.role === 'Admin' && (
              <>
                <Link to="/admin/users">Users</Link>
                <Link to="/admin/tables">Tables</Link>
                <Link to="/admin/settings">Settings</Link>
              </>
            )}
            <span className="user-badge">{user.role}</span>
            <button onClick={handleLogout} className="btn-logout">Logout</button>
          </>
        ) : (
          <>
            <Link to="/login">Login</Link>
            <Link to="/register">Register</Link>
          </>
        )}
      </div>
    </nav>
  );
}
