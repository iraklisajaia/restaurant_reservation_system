import React, { useEffect, useState } from 'react';
import api from '../api/client';

export default function AdminTables() {
  const [tables, setTables] = useState([]);
  const [form, setForm] = useState({ number: '', capacity: '', location: 'Main Hall' });
  const [loading, setLoading] = useState(true);

  const load = () => api.get('/tables').then(r => setTables(r.data)).finally(() => setLoading(false));
  useEffect(load, []);

  const addTable = async (e) => {
    e.preventDefault();
    await api.post('/tables', form);
    setForm({ number: '', capacity: '', location: 'Main Hall' });
    load();
  };

  const deleteTable = async (id) => {
    if (!window.confirm('Delete this table?')) return;
    await api.delete(`/tables/${id}`);
    load();
  };

  if (loading) return <div className="page-loading">Loading...</div>;

  return (
    <div className="page">
      <div className="page-header"><h1>Table Management</h1></div>

      <div className="form-card" style={{ marginBottom: '2rem' }}>
        <h3>Add New Table</h3>
        <form onSubmit={addTable} style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
          <input placeholder="Table #" type="number" value={form.number}
            onChange={e => setForm({ ...form, number: e.target.value })} required style={{ width: '100px' }} />
          <input placeholder="Capacity" type="number" value={form.capacity}
            onChange={e => setForm({ ...form, capacity: e.target.value })} required style={{ width: '100px' }} />
          <input placeholder="Location" value={form.location}
            onChange={e => setForm({ ...form, location: e.target.value })} />
          <button type="submit" className="btn-primary">Add Table</button>
        </form>
      </div>

      <div className="cards-grid">
        {tables.map(t => (
          <div key={t._id} className="reservation-card">
            <div className="card-header">
              <span className="table-label">Table {t.number}</span>
              <button className="btn-sm btn-danger" onClick={() => deleteTable(t._id)}>Remove</button>
            </div>
            <div className="card-body">
              <p>👥 Capacity: {t.capacity}</p>
              <p>📍 {t.location}</p>
            </div>
          </div>
        ))}
        {tables.length === 0 && <p>No tables yet. Add one above.</p>}
      </div>
    </div>
  );
}
