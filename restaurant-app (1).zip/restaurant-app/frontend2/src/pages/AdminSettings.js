import React, { useEffect, useState } from 'react';
import api from '../api/client';

export default function AdminSettings() {
  const [form, setForm] = useState({ restaurantName: '', openingTime: '', closingTime: '', maxPartySize: 12, reservationDuration: 90 });
  const [msg, setMsg] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/settings').then(r => setForm(r.data)).finally(() => setLoading(false));
  }, []);

  const handleSave = async (e) => {
    e.preventDefault();
    await api.put('/settings', form);
    setMsg('Settings saved!');
    setTimeout(() => setMsg(''), 3000);
  };

  if (loading) return <div className="page-loading">Loading...</div>;

  return (
    <div className="page">
      <div className="page-header"><h1>Restaurant Settings</h1></div>
      {msg && <div className="alert alert-success">{msg}</div>}
      <div className="form-card">
        <form onSubmit={handleSave}>
          <div className="form-group">
            <label>Restaurant Name</label>
            <input value={form.restaurantName} onChange={e => setForm({ ...form, restaurantName: e.target.value })} />
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>Opening Time</label>
              <input type="time" value={form.openingTime} onChange={e => setForm({ ...form, openingTime: e.target.value })} />
            </div>
            <div className="form-group">
              <label>Closing Time</label>
              <input type="time" value={form.closingTime} onChange={e => setForm({ ...form, closingTime: e.target.value })} />
            </div>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>Max Party Size</label>
              <input type="number" value={form.maxPartySize} onChange={e => setForm({ ...form, maxPartySize: e.target.value })} />
            </div>
            <div className="form-group">
              <label>Reservation Duration (min)</label>
              <input type="number" value={form.reservationDuration} onChange={e => setForm({ ...form, reservationDuration: e.target.value })} />
            </div>
          </div>
          <button type="submit" className="btn-primary">Save Settings</button>
        </form>
      </div>
    </div>
  );
}
