import React, { useEffect, useState } from 'react';
import api from '../api/client';

const STATUSES = ['Pending', 'Confirmed', 'Seated', 'Completed', 'Cancelled'];
const STATUS_COLORS = {
  Pending: '#f59e0b', Confirmed: '#3b82f6', Seated: '#8b5cf6', Completed: '#10b981', Cancelled: '#ef4444',
};
const NEXT = { Pending: 'Confirmed', Confirmed: 'Seated', Seated: 'Completed' };

export default function ManageReservations() {
  const [reservations, setReservations] = useState([]);
  const [filter, setFilter] = useState('');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  const load = () => {
    api.get('/reservations').then(r => setReservations(r.data)).finally(() => setLoading(false));
  };

  useEffect(load, []);

  const advance = async (id, status) => {
    await api.put(`/reservations/${id}/status`, { status });
    load();
  };

  const filtered = reservations.filter(r => {
    const matchStatus = !filter || r.status === filter;
    const matchSearch = !search ||
      r.customerName?.toLowerCase().includes(search.toLowerCase()) ||
      r.customerEmail?.toLowerCase().includes(search.toLowerCase()) ||
      String(r.tableNumber).includes(search);
    return matchStatus && matchSearch;
  });

  if (loading) return <div className="page-loading">Loading...</div>;

  return (
    <div className="page">
      <div className="page-header">
        <h1>Manage Reservations</h1>
        <span className="count-badge">{filtered.length} records</span>
      </div>

      <div className="filter-bar">
        <input placeholder="Search by name, email, table..." value={search}
          onChange={e => setSearch(e.target.value)} className="search-input" />
        <div className="status-filters">
          <button className={`filter-btn ${!filter ? 'active' : ''}`} onClick={() => setFilter('')}>All</button>
          {STATUSES.map(s => (
            <button key={s} className={`filter-btn ${filter === s ? 'active' : ''}`}
              style={filter === s ? { backgroundColor: STATUS_COLORS[s] } : {}}
              onClick={() => setFilter(s)}>{s}</button>
          ))}
        </div>
      </div>

      <div className="table-wrapper">
        <table className="data-table">
          <thead>
            <tr>
              <th>Customer</th>
              <th>Date & Time</th>
              <th>Table</th>
              <th>Party</th>
              <th>Occasion</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(r => (
              <tr key={r._id}>
                <td>
                  <div>{r.customerName}</div>
                  <small>{r.customerEmail}</small>
                </td>
                <td>{r.date}<br /><small>{r.time}</small></td>
                <td>#{r.tableNumber}</td>
                <td>{r.partySize}</td>
                <td>{r.occasion || '—'}</td>
                <td>
                  <span className="status-badge" style={{ backgroundColor: STATUS_COLORS[r.status] }}>
                    {r.status}
                  </span>
                </td>
                <td className="action-cell">
                  {NEXT[r.status] && (
                    <button className="btn-sm btn-advance" onClick={() => advance(r._id, NEXT[r.status])}>
                      → {NEXT[r.status]}
                    </button>
                  )}
                  {r.status !== 'Cancelled' && r.status !== 'Completed' && (
                    <button className="btn-sm btn-danger" onClick={() => advance(r._id, 'Cancelled')}>
                      Cancel
                    </button>
                  )}
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr><td colSpan={7} style={{ textAlign: 'center', padding: '2rem' }}>No reservations found</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
