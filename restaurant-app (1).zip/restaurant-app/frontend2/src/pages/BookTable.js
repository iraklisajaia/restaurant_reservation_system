import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api/client';

const OCCASIONS = ['', 'Birthday', 'Anniversary', 'Business Dinner', 'Date Night', 'Family Gathering', 'Other'];

export default function BookTable() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ tableNumber: '', date: '', time: '', partySize: 2, occasion: '', notes: '' });
  const [tables, setTables] = useState([]);
  const [availability, setAvailability] = useState({});
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    api.get('/tables').then(r => setTables(r.data)).catch(() => {});
  }, []);

  useEffect(() => {
    if (form.date && form.time) {
      api.get(`/tables/availability?date=${form.date}&time=${form.time}`)
        .then(r => {
          const map = {};
          r.data.forEach(t => { map[t.number] = t.available; });
          setAvailability(map);
          if (form.tableNumber && map[form.tableNumber] === false) {
            setForm(f => ({ ...f, tableNumber: '' }));
          }
        }).catch(() => {});
    }
  }, [form.date, form.time]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(''); setSuccess('');
    if (!form.tableNumber) return setError('Please select a table');
    setLoading(true);
    try {
      await api.post('/reservations', form);
      setSuccess('Reservation submitted! Check My Reservations for status updates.');
      setTimeout(() => navigate('/'), 2000);
    } catch (err) {
      const msg = err.response?.data?.message || 'Booking failed';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleWaitlist = async () => {
    setError(''); setSuccess('');
    try {
      await api.post('/reservations/waitlist', {
        date: form.date, time: form.time, partySize: form.partySize
      });
      setSuccess("You've been added to the waitlist. We'll notify you if a slot opens!");
    } catch (err) {
      setError(err.response?.data?.message || 'Waitlist failed');
    }
  };

  const today = new Date().toISOString().split('T')[0];

  return (
    <div className="page">
      <div className="page-header">
        <h1>Book a Table</h1>
      </div>

      {error && <div className="alert alert-error">{error}
        {error.includes('already booked') && (
          <button className="btn-sm" style={{ marginLeft: '12px' }} onClick={handleWaitlist}>Join Waitlist</button>
        )}
      </div>}
      {success && <div className="alert alert-success">{success}</div>}

      <div className="form-card">
        <form onSubmit={handleSubmit}>
          <div className="form-row">
            <div className="form-group">
              <label>Date</label>
              <input type="date" min={today} value={form.date}
                onChange={e => setForm({ ...form, date: e.target.value })} required />
            </div>
            <div className="form-group">
              <label>Time</label>
              <input type="time" value={form.time}
                onChange={e => setForm({ ...form, time: e.target.value })} required />
            </div>
            <div className="form-group">
              <label>Party Size</label>
              <input type="number" min={1} max={20} value={form.partySize}
                onChange={e => setForm({ ...form, partySize: parseInt(e.target.value) })} required />
            </div>
          </div>

          {tables.length > 0 && (
            <div className="form-group">
              <label>Select Table</label>
              <div className="table-grid">
                {tables.map(t => {
                  const avail = form.date && form.time ? availability[t.number] : true;
                  return (
                    <button key={t._id} type="button"
                      className={`table-btn ${form.tableNumber == t.number ? 'selected' : ''} ${avail === false ? 'unavailable' : ''}`}
                      disabled={avail === false}
                      onClick={() => setForm({ ...form, tableNumber: t.number })}>
                      <span>Table {t.number}</span>
                      <small>{t.capacity} seats · {t.location}</small>
                      {avail === false && <small className="booked-label">Booked</small>}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {tables.length === 0 && (
            <div className="form-group">
              <label>Table Number</label>
              <input type="number" min={1} value={form.tableNumber}
                onChange={e => setForm({ ...form, tableNumber: e.target.value })} required />
            </div>
          )}

          <div className="form-row">
            <div className="form-group">
              <label>Occasion</label>
              <select value={form.occasion} onChange={e => setForm({ ...form, occasion: e.target.value })}>
                {OCCASIONS.map(o => <option key={o} value={o}>{o || 'None'}</option>)}
              </select>
            </div>
          </div>

          <div className="form-group">
            <label>Special Requests</label>
            <textarea rows={3} value={form.notes}
              onChange={e => setForm({ ...form, notes: e.target.value })}
              placeholder="Dietary requirements, accessibility needs, etc." />
          </div>

          <button type="submit" className="btn-primary" disabled={loading}>
            {loading ? 'Booking...' : 'Confirm Reservation'}
          </button>
        </form>
      </div>
    </div>
  );
}
