import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/client';
import { useAuth } from '../context/AuthContext';

const STATUS_COLORS = {
  Pending: '#f59e0b',
  Confirmed: '#3b82f6',
  Seated: '#8b5cf6',
  Completed: '#10b981',
  Cancelled: '#ef4444',
};

export default function Home() {
  const { user } = useAuth();
  const [reservations, setReservations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState(null);

  useEffect(() => {
    api.get('/reservations').then(r => setReservations(r.data)).finally(() => setLoading(false));
  }, []);

  const handleCancel = async (id) => {
    if (!window.confirm('Cancel this reservation?')) return;
    await api.delete(`/reservations/${id}`);
    setReservations(prev => prev.map(r => r._id === id ? { ...r, status: 'Cancelled' } : r));
  };

  if (loading) return <div className="page-loading">Loading reservations...</div>;

  return (
    <div className="page">
      <div className="page-header">
        <h1>My Reservations</h1>
        <Link to="/book" className="btn-primary">+ New Booking</Link>
      </div>

      {reservations.length === 0 ? (
        <div className="empty-state">
          <p>No reservations yet.</p>
          <Link to="/book" className="btn-primary">Book a Table</Link>
        </div>
      ) : (
        <div className="cards-grid">
          {reservations.map(r => (
            <div key={r._id} className="reservation-card">
              <div className="card-header">
                <div>
                  <span className="table-label">Table {r.tableNumber}</span>
                  <span className="party-size">👥 {r.partySize} guests</span>
                </div>
                <span className="status-badge" style={{ backgroundColor: STATUS_COLORS[r.status] }}>
                  {r.status}
                </span>
              </div>
              <div className="card-body">
                <p>📅 {r.date} at {r.time}</p>
                {r.occasion && <p>🎉 {r.occasion}</p>}
                {r.notes && <p>📝 {r.notes}</p>}
              </div>
              <div className="card-actions">
                <button className="btn-sm" onClick={() => setExpanded(expanded === r._id ? null : r._id)}>
                  {expanded === r._id ? 'Hide History' : 'View History'}
                </button>
                {r.status === 'Pending' && (
                  <button className="btn-sm btn-danger" onClick={() => handleCancel(r._id)}>Cancel</button>
                )}
              </div>
              {expanded === r._id && (
                <div className="history-log">
                  <h4>Status History</h4>
                  {r.history?.map((h, i) => (
                    <div key={i} className="history-item">
                      <span className="history-status" style={{ color: STATUS_COLORS[h.status] }}>{h.status}</span>
                      <span className="history-note">{h.note}</span>
                      <span className="history-time">{new Date(h.timestamp).toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
