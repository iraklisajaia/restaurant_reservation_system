import React, { useEffect, useState } from 'react';
import api from '../api/client';

const TYPE_COLORS = { info: '#3b82f6', success: '#10b981', warning: '#f59e0b', error: '#ef4444' };

export default function Notifications() {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = () => api.get('/notifications').then(r => setNotifications(r.data)).finally(() => setLoading(false));
  useEffect(load, []);

  const markRead = async (id) => {
    await api.put(`/notifications/${id}/read`);
    setNotifications(prev => prev.map(n => n._id === id ? { ...n, read: true } : n));
  };

  const markAllRead = async () => {
    await api.put('/notifications/read-all');
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const unread = notifications.filter(n => !n.read).length;

  if (loading) return <div className="page-loading">Loading...</div>;

  return (
    <div className="page">
      <div className="page-header">
        <h1>Notifications {unread > 0 && <span className="unread-badge">{unread}</span>}</h1>
        {unread > 0 && <button className="btn-sm" onClick={markAllRead}>Mark all read</button>}
      </div>

      {notifications.length === 0 ? (
        <div className="empty-state"><p>No notifications yet.</p></div>
      ) : (
        <div className="notifications-list">
          {notifications.map(n => (
            <div key={n._id} className={`notification-item ${n.read ? 'read' : 'unread'}`}
              onClick={() => !n.read && markRead(n._id)}>
              <span className="notif-dot" style={{ backgroundColor: TYPE_COLORS[n.type] }} />
              <div className="notif-content">
                <p>{n.message}</p>
                <small>{new Date(n.createdAt).toLocaleString()}</small>
              </div>
              {!n.read && <span className="unread-indicator">●</span>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
