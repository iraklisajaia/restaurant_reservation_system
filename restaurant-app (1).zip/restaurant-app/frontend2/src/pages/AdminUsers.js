import React, { useEffect, useState } from 'react';
import api from '../api/client';
import { useAuth } from '../context/AuthContext';

export default function AdminUsers() {
  const { user: me } = useAuth();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = () => api.get('/users').then(r => setUsers(r.data)).finally(() => setLoading(false));
  useEffect(load, []);

  const changeRole = async (id, role) => {
    await api.put(`/users/${id}/role`, { role });
    load();
  };

  const toggleStatus = async (id, isActive) => {
    await api.put(`/users/${id}/status`, { isActive });
    load();
  };

  const deleteUser = async (id) => {
    if (!window.confirm('Delete this user?')) return;
    await api.delete(`/users/${id}`);
    load();
  };

  if (loading) return <div className="page-loading">Loading...</div>;

  return (
    <div className="page">
      <div className="page-header"><h1>User Management</h1></div>
      <div className="table-wrapper">
        <table className="data-table">
          <thead>
            <tr><th>Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Status</th><th>Actions</th></tr>
          </thead>
          <tbody>
            {users.map(u => (
              <tr key={u._id}>
                <td>{u.name}</td>
                <td>{u.email}</td>
                <td>{u.phone || '—'}</td>
                <td>
                  <select value={u.role} onChange={e => changeRole(u._id, e.target.value)}
                    disabled={u._id === me?.id} className="role-select">
                    {['Customer', 'Staff', 'Admin'].map(r => <option key={r}>{r}</option>)}
                  </select>
                </td>
                <td>
                  <span className={`status-badge ${u.isActive ? 'active' : 'inactive'}`}>
                    {u.isActive ? 'Active' : 'Inactive'}
                  </span>
                </td>
                <td className="action-cell">
                  {u._id !== me?.id && (
                    <>
                      <button className="btn-sm" onClick={() => toggleStatus(u._id, !u.isActive)}>
                        {u.isActive ? 'Deactivate' : 'Activate'}
                      </button>
                      <button className="btn-sm btn-danger" onClick={() => deleteUser(u._id)}>Delete</button>
                    </>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
